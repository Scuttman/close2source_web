1:"$Sreact.fragment"
2:I[17989,[],"ClientSegmentRoot"]
3:I[12895,["2992","static/chunks/bc9e92e6-0bd1ca534cc16819.js","7416","static/chunks/69806262-d206853fc26b89cd.js","3947","static/chunks/3947-f04f267842808e69.js","2619","static/chunks/2619-04bc32f026a0d946.js","3624","static/chunks/3624-352e118b86679c03.js","5607","static/chunks/5607-146359cfeab0e2a1.js","7177","static/chunks/app/layout-e3aa491f6d5f88a9.js"],"default"]
4:I[9766,[],""]
5:I[98924,[],""]
7:I[81959,[],"ClientPageRoot"]
8:I[65657,["2992","static/chunks/bc9e92e6-0bd1ca534cc16819.js","7416","static/chunks/69806262-d206853fc26b89cd.js","3947","static/chunks/3947-f04f267842808e69.js","2619","static/chunks/2619-04bc32f026a0d946.js","3624","static/chunks/3624-352e118b86679c03.js","893","static/chunks/app/projects/page-6cdf915f6863add5.js"],"default"]
b:I[24431,[],"OutletBoundary"]
d:I[15278,[],"AsyncMetadataOutlet"]
f:I[24431,[],"ViewportBoundary"]
11:I[24431,[],"MetadataBoundary"]
12:"$Sreact.suspense"
14:I[57150,[],""]
:HL["/_next/static/media/e4af272ccee01ff0-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/6cd4e3c0fcf3bac1.css","style"]
0:{"P":null,"b":"oGLIPW7gm1iDWvktiIxUZ","p":"","c":["","projects"],"i":false,"f":[[["",{"children":["projects",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/6cd4e3c0fcf3bac1.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]},"params":{},"promise":"$@6"}]]}],{"children":["projects",["$","$1","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L7",null,{"Component":"$8","searchParams":{},"params":"$0:f:0:1:1:props:children:1:props:params","promises":["$@9","$@a"]}],null,["$","$Lb",null,{"children":["$Lc",["$","$Ld",null,{"promise":"$@e"}]]}]]}],{},null,false]},null,false]},null,false],["$","$1","h",{"children":[null,[["$","$Lf",null,{"children":"$L10"}],["$","meta",null,{"name":"next-size-adjust","content":""}]],["$","$L11",null,{"children":["$","div",null,{"hidden":true,"children":["$","$12",null,{"fallback":null,"children":"$L13"}]}]}]]}],false]],"m":"$undefined","G":["$14",[]],"s":false,"S":true}
6:"$0:f:0:1:1:props:children:1:props:params"
9:{}
a:"$0:f:0:1:1:props:children:1:props:params"
10:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
c:null
e:{"metadata":[],"error":null,"digest":"$undefined"}
13:"$e:metadata"
